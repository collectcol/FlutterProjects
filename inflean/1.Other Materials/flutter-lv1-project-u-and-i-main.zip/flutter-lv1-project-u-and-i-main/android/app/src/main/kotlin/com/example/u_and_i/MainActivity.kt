package com.example.u_and_i

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
